import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class EmploymentManagementApp implements ActionListener {
    private JFrame frame;
    private JTextField idField, nameField, positionField, salaryField;
    private JTextArea outputArea;
    private Map<Integer, Employee> employeeDatabase;

    public EmploymentManagementApp() {
        employeeDatabase = new HashMap<>();

        frame = new JFrame("Employment Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Employee Details"));

        JLabel idLabel = new JLabel("Employee ID:");
        JLabel nameLabel = new JLabel("Name:");
        JLabel positionLabel = new JLabel("Position:");
        JLabel salaryLabel = new JLabel("Salary:");

        idField = new JTextField();
        nameField = new JTextField();
        positionField = new JTextField();
        salaryField = new JTextField();

        inputPanel.add(idLabel); inputPanel.add(idField);
        inputPanel.add(nameLabel); inputPanel.add(nameField);
        inputPanel.add(positionLabel); inputPanel.add(positionField);
        inputPanel.add(salaryLabel); inputPanel.add(salaryField);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 5, 10, 10));
        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        JButton viewButton = new JButton("View All");
        JButton searchButton = new JButton("Search");

        addButton.addActionListener(this);
        updateButton.addActionListener(this);
        deleteButton.addActionListener(this);
        viewButton.addActionListener(this);
        searchButton.addActionListener(this);

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(searchButton);

        outputArea = new JTextArea(15, 50);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        try {
            switch (command) {
                case "Add": addEmployee(); break;
                case "Update": updateEmployee(); break;
                case "Delete": deleteEmployee(); break;
                case "View All": viewAllEmployees(); break;
                case "Search": searchEmployee(); break;
            }
        } catch (NumberFormatException ex) {
            outputArea.append("Invalid input. Please enter valid values.\n");
        }
    }

    private void addEmployee() {
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        String position = positionField.getText();
        double salary = Double.parseDouble(salaryField.getText());

        if (employeeDatabase.containsKey(id)) {
            outputArea.append("Employee with ID " + id + " already exists.\n");
        } else {
            Employee employee = new Employee(id, name, position, salary);
            employeeDatabase.put(id, employee);
            outputArea.append("Employee added successfully.\n");
        }
        clearFields();
    }

    private void updateEmployee() {
        int id = Integer.parseInt(idField.getText());
        if (employeeDatabase.containsKey(id)) {
            Employee employee = employeeDatabase.get(id);
            employee.setName(nameField.getText());
            employee.setPosition(positionField.getText());
            employee.setSalary(Double.parseDouble(salaryField.getText()));
            outputArea.append("Employee updated successfully.\n");
        } else {
            outputArea.append("Employee with ID " + id + " not found.\n");
        }
        clearFields();
    }

    private void deleteEmployee() {
        int id = Integer.parseInt(idField.getText());
        if (employeeDatabase.remove(id) != null) {
            outputArea.append("Employee deleted successfully.\n");
        } else {
            outputArea.append("Employee with ID " + id + " not found.\n");
        }
        clearFields();
    }

    private void viewAllEmployees() {
        if (employeeDatabase.isEmpty()) {
            outputArea.append("No employees found.\n");
        } else {
            outputArea.append("Employee List:\n");
            for (Employee employee : employeeDatabase.values()) {
                outputArea.append(employee.toString() + "\n");
            }
        }
    }

    private void searchEmployee() {
        int id = Integer.parseInt(idField.getText());
        Employee employee = employeeDatabase.get(id);
        if (employee != null) {
            outputArea.append("Employee Details:\n" + employee.toString() + "\n");
        } else {
            outputArea.append("Employee with ID " + id + " not found.\n");
        }
        clearFields();
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        positionField.setText("");
        salaryField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EmploymentManagementApp::new);
    }
}
