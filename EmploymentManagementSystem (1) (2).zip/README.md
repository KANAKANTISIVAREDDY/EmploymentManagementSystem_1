# Employment Management System

A simple Java Swing GUI application for managing employees.

## Features
- Add, Update, Delete employees
- View all employees
- Search employee by ID

## Requirements
- Java SE Development Kit (JDK) 8+
- Eclipse IDE (optional)

## Run
```bash
javac src/*.java
java -cp src EmploymentManagementApp
```
